/* =====================================================
   1. JE KAARTEN
   v       = vraag (voorkant)
   a       = antwoord (achterkant)
   o       = (optioneel) onderwerp / onderhoofdstuk, staat bovenaan de kaart
   uitleg  = (optioneel) kleine extra uitleg onder het antwoord
   Zonder "o" zie je gewoon de naam van het hoofdstuk.
   ===================================================== */
/* Als een kaartenbestand niet geladen is, crasht de app niet maar toont ze welk bestand ontbreekt */
const ontbrekendeBestanden = [];
function ontbreekt(bestand) {
  ontbrekendeBestanden.push(bestand);
  return [{ v: "⚠️ Het bestand " + bestand + " is niet gevonden.", a: "Zet " + bestand + " in dezelfde map als index.html (exact deze naam), en controleer of index.html er een <script>-regel voor heeft. Druk daarna op Ctrl+F5.", o: "Ontbrekend bestand" }];
}

const vakken = {
  "🌐 Web Essentials": {
    "H1 – HTML": [
      { v: "Waar staat HTML voor?", a: "HyperText Markup Language", o: "1.1 Wat is HTML?" },
      { v: "Welke tag gebruik je voor de grootste titel?", a: "<h1>", o: "1.2 Tags" },
      { v: "Welke tag maakt een link?", a: "<a href=\"...\">", o: "1.2 Tags" },
    ],
    "H2 – CSS": [
      { v: "Waar staat CSS voor?", a: "Cascading Style Sheets", o: "2.1 Basis" },
      { v: "Hoe selecteer je een element met id=\"menu\"?", a: "#menu", o: "2.2 Selectors" },
      { v: "Hoe selecteer je alle elementen met class=\"knop\"?", a: ".knop", o: "2.2 Selectors" },
    ],
  },
  "💻 IT Essentials": {
    // ===== Deel I: Getalrepresentaties en schakelingen =====
    "I.1 – Talstelsels en codesystemen": (typeof kaarten_IT_deel1_les1 !== "undefined" ? kaarten_IT_deel1_les1 : ontbreekt("flashcards_ITdeel1les1_talstelsels.js")),
    "I.2 – Logische poorten en schakelingen": (typeof kaarten_IT_deel1_les2 !== "undefined" ? kaarten_IT_deel1_les2 : ontbreekt("flashcards_ITdeel1les2_logischepoorten.js")),
    "I.3 – Rekenschakelingen": (typeof kaarten_IT_deel1_les3 !== "undefined" ? kaarten_IT_deel1_les3 : ontbreekt("flashcards_ITdeel1les3_rekenschakelingen.js")),
    // ===== Deel II: Hardwarecomponenten =====
    // kaarten staan in flashcards_ITdeel2les1_computerarchitectuur.js
    "II.1 – Computerarchitectuur": (typeof kaarten_IT_deel2_les1 !== "undefined" ? kaarten_IT_deel2_les1 : ontbreekt("flashcards_ITdeel2les1_computerarchitectuur.js")),
    // kaarten staan in flashcards_ITdeel2les2_werkgeheugen.js
    "II.2 – Werkgeheugen": (typeof kaarten_IT_deel2_les2 !== "undefined" ? kaarten_IT_deel2_les2 : ontbreekt("flashcards_ITdeel2les2_werkgeheugen.js")),
    // kaarten staan in flashcards_ITdeel2les3_processoren.js
    "II.3 – Processoren": (typeof kaarten_IT_deel2_les3 !== "undefined" ? kaarten_IT_deel2_les3 : ontbreekt("flashcards_ITdeel2les3_processoren.js")),
    // kaarten staan in flashcards_ITdeel2les4_chipsets.js
    "II.4 – Chipsets en bussen": (typeof kaarten_IT_deel2_les4 !== "undefined" ? kaarten_IT_deel2_les4 : ontbreekt("flashcards_ITdeel2les4_chipsets.js")),
    // kaarten staan in flashcards_ITdeel2les5_magnetisch.js
    "II.5 – Magnetische opslag": (typeof kaarten_IT_deel2_les5 !== "undefined" ? kaarten_IT_deel2_les5 : ontbreekt("flashcards_ITdeel2les5_magnetisch.js")),
  },
  "📊 Data Essentials": {
    "H1 – Databanken": [
      { v: "Wat is een primaire sleutel?", a: "Een veld dat elke rij in een tabel uniek identificeert", o: "1.1 Tabellen" },
      { v: "Met welk SQL-commando haal je gegevens op?", a: "SELECT", o: "1.2 SQL" },
    ],
  },
  "🖥️ Desktop OS": {
    // ===== Deel I: Linux =====
    "I.0 – Linux: introductie": (typeof kaarten_DOS_linux_intro !== "undefined" ? kaarten_DOS_linux_intro : ontbreekt("flashcards_DesktopOS_linux_intro.js")),
    "I.1 – Linux: werkcollege 1": (typeof kaarten_DOS_linux_wc1 !== "undefined" ? kaarten_DOS_linux_wc1 : ontbreekt("flashcards_DesktopOS_linux_wc1.js")),
    "I.2 – Linux: werkcollege 2": (typeof kaarten_DOS_linux_wc2 !== "undefined" ? kaarten_DOS_linux_wc2 : ontbreekt("flashcards_DesktopOS_linux_wc2.js")),
    "I.3 – Linux: werkcollege 3": (typeof kaarten_DOS_linux_wc3 !== "undefined" ? kaarten_DOS_linux_wc3 : ontbreekt("flashcards_DesktopOS_linux_wc3.js")),
    // ===== Deel II: Windows (nog aan te vullen) =====
    "II – Windows": [
      { v: "Welk commando toont je IP-configuratie in Windows?", a: "ipconfig", o: "1.1 Command Prompt" },
      { v: "Wat is het verschil tussen een standaard- en een administratoraccount?", a: "Een administrator mag systeeminstellingen wijzigen en software installeren, een standaardgebruiker niet", o: "1.2 Gebruikers" },
    ],
  },
};

/* ===== Vanaf hier hoef je niets aan te passen ===== */
let huidigVak = null;
let gekozenHoofdstukken = [];
let stapel = [];
let index = 0;
let fouten = [];

/* Alles wat onthouden wordt, staat in de browser (localStorage) */
function laad(sleutel, standaard) {
  try { return JSON.parse(localStorage.getItem(sleutel)) || standaard; } catch (e) { return standaard; }
}
function bewaar(sleutel, waarde) {
  try { localStorage.setItem(sleutel, JSON.stringify(waarde)); } catch (e) {}
}

let verborgen = new Set(laad("verborgen", []));   // weggegooide kaarten
let stats = laad("stats", {});                      // per kaart: hoe vaak goed/fout + laatste antwoord
let scores = laad("scores", {});                    // per vak: je laatste scores
let posities = laad("posities", {});                // waar je gebleven was (enkel zonder schudden)
let hervatbaar = false;                             // huidige ronde onthoudt zijn plaats?

/* Eenmalig: voortgang van het oude hoofdstuk "introductie en werkcollege 1" overzetten naar de 2 nieuwe hoofdstukken */
(function migreerLinuxSplitsing() {
  const vak = "🖥️ Desktop OS|";
  const oud = vak + "I.1 – Linux: introductie en werkcollege 1|";
  if (typeof kaarten_DOS_linux_intro === "undefined") return;
  const introVragen = new Set(kaarten_DOS_linux_intro.map(k => k.v));
  const nieuweSleutel = id => {
    const v = id.slice(oud.length);
    return vak + (introVragen.has(v) ? "I.0 – Linux: introductie" : "I.1 – Linux: werkcollege 1") + "|" + v;
  };
  let gewijzigd = false;
  for (const id of Object.keys(stats)) {
    if (id.startsWith(oud)) { stats[nieuweSleutel(id)] = stats[id]; delete stats[id]; gewijzigd = true; }
  }
  for (const id of [...verborgen]) {
    if (id.startsWith(oud)) { verborgen.delete(id); verborgen.add(nieuweSleutel(id)); gewijzigd = true; }
  }
  for (const p of Object.keys(posities)) {
    if (p.includes("introductie en werkcollege 1")) { delete posities[p]; gewijzigd = true; }
  }
  if (gewijzigd) { bewaar("stats", stats); bewaar("verborgen", [...verborgen]); bewaar("posities", posities); }
})();

function bewaarVerborgen() { bewaar("verborgen", [...verborgen]); }

function wasFout(id) { return stats[id] && stats[id].laatst === false; }

function kaartId(vak, hfst, kaart) {
  return vak + "|" + hfst + "|" + kaart.v;
}

function toonScherm(id) {
  document.querySelectorAll(".scherm").forEach(s => s.classList.remove("actief"));
  document.getElementById(id).classList.add("actief");
  bewaarSessie();
}

/* ===== Bij vernieuwen (refresh) blijf je op hetzelfde scherm =====
   Bewaard in sessionStorage: blijft bestaan zolang dit tabblad open is. */
function bewaarSessie() {
  try {
    const actief = document.querySelector(".scherm.actief");
    const s = { scherm: actief ? actief.id : "schermVak", vak: huidigVak, hfst: gekozenHoofdstukken };
    if (s.scherm === "schermHoofdstuk") s.aangevinkt = aangevinkteHoofdstukken();
    if (s.scherm === "schermOefenen") {
      s.stapel = stapel.map(k => [k.hfst, k.v]);
      s.fouten = fouten.map(k => [k.hfst, k.v]);
      s.index = index;
      s.hervatbaar = hervatbaar;
    }
    sessionStorage.setItem("sessie", JSON.stringify(s));
  } catch (e) {}
}

function herstelSessie() {
  let s = null;
  try { s = JSON.parse(sessionStorage.getItem("sessie")); } catch (e) {}
  if (!s || !s.vak || !vakken[s.vak] || s.scherm === "schermVak") return;
  gekozenHoofdstukken = (s.aangevinkt || s.hfst || []).filter(h => vakken[s.vak][h]);
  kiesVak(s.vak);
  if (s.scherm === "schermWeggegooid") { toonWeggegooid(); return; }
  if (s.scherm !== "schermOefenen" || !s.stapel) return;
  // de ronde opnieuw opbouwen, kaart per kaart, in dezelfde volgorde
  const zoek = ([hfst, v]) => {
    const k = (vakken[s.vak][hfst] || []).find(x => x.v === v);
    return k && !verborgen.has(kaartId(s.vak, hfst, k)) ? { ...k, hfst } : null;
  };
  const kaarten = s.stapel.map(zoek).filter(Boolean);
  if (kaarten.length === 0) return;
  gekozenHoofdstukken = (s.hfst || []).filter(h => vakken[s.vak][h]);
  stapel = kaarten;
  fouten = (s.fouten || []).map(zoek).filter(Boolean);
  index = Math.min(Math.max(s.index || 0, 0), stapel.length - 1);
  acties = [];
  hervatbaar = !!s.hervatbaar;
  zetEenhoornStand();
  toonScherm("schermOefenen");
  toonKaart();
}

function toonVakken() {
  const lijst = document.getElementById("vakLijst");
  lijst.innerHTML = "";
  for (const vak in vakken) {
    const knop = document.createElement("button");
    knop.className = "licht";
    knop.textContent = vak;
    knop.onclick = () => { gekozenHoofdstukken = []; kiesVak(vak); };
    lijst.appendChild(knop);
  }
  if (ontbrekendeBestanden.length) {
    const p = document.createElement("p");
    p.style.cssText = "color:#f5a623;text-align:left;font-size:.9em";
    p.textContent = "⚠️ Niet gevonden: " + ontbrekendeBestanden.join(", ") + " — zet deze bestanden in dezelfde map als index.html en druk Ctrl+F5.";
    lijst.appendChild(p);
  }
}

function kiesVak(vak) {
  huidigVak = vak;
  document.getElementById("vakTitel").textContent = vak;
  document.getElementById("alles").checked = false;
  const lijst = document.getElementById("hoofdstukLijst");
  lijst.innerHTML = "";
  let aantalWeg = 0;

  for (const hfst in vakken[vak]) {
    const kaarten = vakken[vak][hfst];
    const weg = kaarten.filter(k => verborgen.has(kaartId(vak, hfst, k))).length;
    // % juist/fout van het totaal aantal kaarten, op basis van je laatste antwoord per kaart
    // (weggegooide kaarten tellen niet mee)
    const actief = kaarten.filter(k => !verborgen.has(kaartId(vak, hfst, k)));
    const goedAantal = actief.filter(k => { const st = stats[kaartId(vak, hfst, k)]; return st && st.laatst === true; }).length;
    const foutAantal = actief.filter(k => wasFout(kaartId(vak, hfst, k))).length;
    const beantwoord = goedAantal + foutAantal;
    const pct = n => actief.length ? Math.round(n / actief.length * 100) : 0;
    aantalWeg += weg;
    const aangevinkt = gekozenHoofdstukken.includes(hfst) ? "checked" : "";
    lijst.innerHTML += `
      <label class="hoofdstuk">
        <input type="checkbox" value="${hfst}" ${aangevinkt}>
        <span class="hfst-naam">${hfst}</span>
        <small>
          <span>${actief.length} kaarten${beantwoord ? ` · ${beantwoord} beantwoord` : ""}</span>
          ${goedAantal || foutAantal ? `<span><span class="groen">${pct(goedAantal)}% juist</span> · <span class="rood">${pct(foutAantal)}% fout</span></span>` : ""}
        </small>
      </label>`;
  }

  const terug = document.getElementById("terugzetten");
  terug.style.display = aantalWeg ? "block" : "none";
  terug.textContent = `♻️ ${aantalWeg} weggegooide kaart${aantalWeg === 1 ? "" : "en"} bekijken`;

  toonVerderInfo();
  toonScherm("schermHoofdstuk");
}

/* ---------- Verderzetten waar je gebleven was ---------- */
// sleutel = vak + de aangevinkte hoofdstukken (elke combinatie onthoudt zijn eigen plaats)
function aangevinkteHoofdstukken() {
  return [...document.querySelectorAll("#hoofdstukLijst input:checked")].map(c => c.value);
}
function positieSleutel(hoofdstukken = gekozenHoofdstukken) {
  return huidigVak + "|" + hoofdstukken.join("+");
}
// alle kaarten van de hoofdstukken in volgorde van je js-bestanden (zonder filters)
function volledigeVolgorde(hoofdstukken) {
  return hoofdstukken.flatMap(h => vakken[huidigVak][h].map(k => kaartId(huidigVak, h, k)));
}
// zoekt in de stapel de kaart waar je was; is die er niet meer (weggegooid, gefilterd),
// dan de eerstvolgende kaart die er wel nog is
function hervatIndex() {
  const id = posities[positieSleutel()];
  if (!id) return 0;
  const volgorde = volledigeVolgorde(gekozenHoofdstukken);
  const plaats = volgorde.indexOf(id);
  if (plaats < 0) return 0;
  const i = stapel.findIndex(k => volgorde.indexOf(kaartId(huidigVak, k.hfst, k)) >= plaats);
  return i < 0 ? 0 : i;
}
// toont onder de Start-knop of je verder gaat, met een link om opnieuw te beginnen
function toonVerderInfo() {
  const info = document.getElementById("verderInfo");
  if (!info) return;
  const hfst = aangevinkteHoofdstukken();
  const id = hfst.length ? posities[positieSleutel(hfst)] : null;
  const volgorde = id ? volledigeVolgorde(hfst) : [];
  const plaats = volgorde.indexOf(id);
  if (!id || plaats < 0 || document.getElementById("schudden").checked) { info.style.display = "none"; return; }
  info.style.display = "block";
  info.innerHTML = `▶ Je gaat verder bij kaart ${plaats + 1} van ${volgorde.length} · ` +
    `<a href="#" onclick="beginOpnieuw(); return false;">opnieuw beginnen</a>`;
}
function beginOpnieuw() {
  delete posities[positieSleutel(aangevinkteHoofdstukken())];
  bewaar("posities", posities);
  toonVerderInfo();
}

function toonGeschiedenis() {
  const vak = document.getElementById("geschiedenis");
  if (!vak) return;   // het blok "Je laatste scores" staat niet meer op de pagina
  const lijst = (scores[huidigVak] || []).slice(-5).reverse();
  if (lijst.length === 0) { vak.style.display = "none"; return; }
  vak.style.display = "block";
  vak.innerHTML = "<h3>📈 Je laatste scores</h3>" +
    lijst.map(s => `<div><span>${s.datum}</span><b>${s.goed} / ${s.totaal}</b></div>`).join("") +
    `<button class="terug" onclick="wisVoortgang()">Voortgang van dit vak wissen</button>`;
}

function wisVoortgang() {
  if (!confirm("Alle scores en foute kaarten van dit vak wissen?")) return;
  delete scores[huidigVak];
  for (const id in stats) if (id.startsWith(huidigVak + "|")) delete stats[id];
  bewaar("scores", scores);
  bewaar("stats", stats);
  kiesVak(huidigVak);
}

function vinkAlles(aan) {
  document.querySelectorAll("#hoofdstukLijst input").forEach(c => c.checked = aan);
}

/* ===== Filter: nog niet beantwoord / fout / juist ===== */
function statusVan(id) {
  const st = stats[id];
  if (!st || st.laatst === undefined) return "nieuw";
  return st.laatst ? "juist" : "fout";
}

function gekozenFilters() {
  return {
    nieuw: document.getElementById("fNieuw").checked,
    fout:  document.getElementById("fFout").checked,
    juist: document.getElementById("fJuist").checked,
  };
}

/* ===== Weggegooide kaarten bekijken en kiezen wat terug mag ===== */
function toonWeggegooid() {
  const lijst = document.getElementById("wegLijst");
  let html = "";

  for (const hfst in vakken[huidigVak]) {
    const weg = vakken[huidigVak][hfst].filter(k => verborgen.has(kaartId(huidigVak, hfst, k)));
    if (weg.length === 0) continue;
    html += `<h3 class="weg-hoofdstuk">${hfst} <small>(${weg.length})</small></h3><div class="weg-raster">`;
    for (const k of weg) {
      const id = kaartId(huidigVak, hfst, k);
      html += `
        <label class="weg-kaart">
          <input type="checkbox" data-id="${encodeURIComponent(id)}" onchange="telGeselecteerd()">
          <span>
            <span class="weg-vraag">${k.img ? "🖼️ " : ""}${maakVeilig(k.v)}</span>
            <span class="weg-antwoord">${maakVeilig(k.a)}</span>
            <span class="weg-bron" data-vraag="${encodeURIComponent(k.v)}">📄 bestand zoeken…</span>
          </span>
        </label>`;
    }
    html += `</div>`;
  }
  lijst.innerHTML = html || `<p class="hint">Je hebt geen weggegooide kaarten in dit vak.</p>`;
  telGeselecteerd();
  toonScherm("schermWeggegooid");
  vulBronnenIn();
}

/* Bij elke weggegooide kaart tonen in welk .js-bestand en op welke regel ze staat,
   zodat je ze daar manueel kan aanpassen of verwijderen.
   De app leest daarvoor zelf de geladen scriptbestanden in. Dat lukt alleen via
   een webadres (bv. Live Server), niet als je index.html rechtstreeks opent (file://). */
const bestandTekst = {};   // cache: bestandsnaam -> inhoud

async function laadScripts() {
  const namen = [...document.scripts].map(sc => sc.getAttribute("src")).filter(Boolean);
  await Promise.all(namen.map(async naam => {
    if (naam.split("?")[0] in bestandTekst) return;
    try {
      const r = await fetch(naam);
      bestandTekst[naam.split("?")[0]] = r.ok ? await r.text() : null;   // zonder ?v=… in de lijst
    } catch (e) { bestandTekst[naam.split("?")[0]] = null; }
  }));
}

// zoekt in welk bestand en op welke regel een vraag staat (null als niet gevonden)
function bronVan(vraag) {
  const zoek = "v: " + JSON.stringify(vraag);
  for (const naam in bestandTekst) {
    const tekst = bestandTekst[naam];
    if (!tekst) continue;
    let pos = tekst.indexOf(zoek);
    if (pos === -1) pos = tekst.indexOf(vraag);
    if (pos === -1) continue;
    return { naam, regel: tekst.slice(0, pos).split("\n").length };
  }
  return null;
}

async function vulBronnenIn() {
  await laadScripts();
  const gelukt = Object.values(bestandTekst).some(t => t);
  document.querySelectorAll(".weg-bron").forEach(el => {
    const vraag = decodeURIComponent(el.dataset.vraag);
    if (!gelukt) {
      el.textContent = "📄 open de app via Live Server om het bestand en de regel te zien";
      return;
    }
    const bron = bronVan(vraag);
    if (bron) {
      el.textContent = `📄 ${bron.naam} · regel ${bron.regel}`;
      el.title = "Open dit bestand in VS Code en druk Ctrl+G om naar de regel te springen";
    } else {
      el.textContent = "📄 niet gevonden in de bestanden";
    }
  });
}

/* Lijst van alle weggegooide kaarten van dit vak als tekst, per bestand gegroepeerd.
   Die kan je kopiëren en in de chat plakken, zodat ze uit de js-bestanden verwijderd kunnen worden. */
async function maakWegLijstTekst() {
  await laadScripts();
  const perBestand = {};
  let aantal = 0;
  for (const hfst in vakken[huidigVak]) {
    for (const k of vakken[huidigVak][hfst]) {
      if (!verborgen.has(kaartId(huidigVak, hfst, k))) continue;
      const bron = bronVan(k.v);
      const sleutel = bron ? bron.naam : `(bestand onbekend – ${hfst})`;
      (perBestand[sleutel] = perBestand[sleutel] || []).push({ regel: bron ? bron.regel : null, v: k.v });
      aantal++;
    }
  }
  let tekst = `Weggegooide kaarten – ${huidigVak} (${aantal})\n` +
              `Verwijder deze kaarten uit de js-bestanden:\n`;
  for (const naam in perBestand) {
    tekst += `\n${naam}\n`;
    for (const k of perBestand[naam].sort((x, y) => (x.regel || 0) - (y.regel || 0)))
      tekst += `- ${k.regel ? "regel " + k.regel + ": " : ""}${k.v}\n`;
  }
  return tekst;
}

async function kopieerWegLijst() {
  const knop = document.getElementById("kopieerKnop");
  const tekst = await maakWegLijstTekst();
  try {
    await navigator.clipboard.writeText(tekst);
    knop.textContent = "✓ Gekopieerd";
  } catch (e) {
    // kopiëren niet toegelaten? dan als tekstbestand downloaden
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([tekst], { type: "text/plain" }));
    a.download = "weggegooide-kaarten.txt";
    a.click();
    knop.textContent = "✓ Gedownload als weggegooide-kaarten.txt";
  }
  setTimeout(() => { knop.textContent = "📋 Lijst kopiëren"; }, 3000);
}

/* tekens als < en > in vragen (bv. "<h1>") tonen in plaats van uitvoeren */
function maakVeilig(tekst) {
  const d = document.createElement("div");
  d.textContent = tekst;
  return d.innerHTML;
}

function telGeselecteerd() {
  const n = document.querySelectorAll("#wegLijst input:checked").length;
  const knop = document.getElementById("wegKnop");
  knop.disabled = n === 0;
  knop.textContent = n ? `${n} kaart${n === 1 ? "" : "en"} terugzetten` : "Vink kaarten aan om terug te zetten";
}

function zetGeselecteerdTerug() {
  document.querySelectorAll("#wegLijst input:checked")
    .forEach(c => verborgen.delete(decodeURIComponent(c.dataset.id)));
  bewaarVerborgen();
  // nog kaarten over? dan blijf je in de lijst, anders terug naar de hoofdstukken
  const nogOver = [...verborgen].some(id => id.startsWith(huidigVak + "|"));
  if (nogOver) toonWeggegooid(); else kiesVak(huidigVak);
}

function schud(lijst) {
  for (let i = lijst.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [lijst[i], lijst[j]] = [lijst[j], lijst[i]];
  }
  return lijst;
}

function startOefenen(kaarten) {
  const gewoneStart = !kaarten;
  if (!kaarten) {
    gekozenHoofdstukken = [...document.querySelectorAll("#hoofdstukLijst input:checked")].map(c => c.value);
    if (gekozenHoofdstukken.length === 0) { alert("Kies minstens één hoofdstuk."); return; }
    kaarten = gekozenHoofdstukken
      .flatMap(h => vakken[huidigVak][h].map(k => ({ ...k, hfst: h })))
      .filter(k => !verborgen.has(kaartId(huidigVak, k.hfst, k)));
    if (kaarten.length === 0) { alert("Er zijn geen kaarten meer over in deze hoofdstukken."); return; }
    // filter: nog niet beantwoord / fout / juist
    const wil = gekozenFilters();
    if (!wil.nieuw && !wil.fout && !wil.juist) { alert("Vink minstens één soort kaarten aan."); return; }
    kaarten = kaarten.filter(k => wil[statusVan(kaartId(huidigVak, k.hfst, k))]);
    if (kaarten.length === 0) { alert("Er zijn geen kaarten van die soort in deze hoofdstukken 🎉"); return; }
  }
  stapel = [...kaarten];
  const geschud = document.getElementById("schudden").checked;
  if (geschud) schud(stapel);
  index = 0;
  fouten = [];
  acties = [];
  zetEenhoornStand();   // al boven 50%? dan pas opnieuw na eerst onder 50% te zakken
  // niet geschud? dan ga je verder waar je de vorige keer gebleven was
  hervatbaar = gewoneStart && !geschud;
  if (hervatbaar) index = hervatIndex();
  toonScherm("schermOefenen");
  toonKaart();
}

/* Telt je laatste antwoord per kaart (over al je sessies), voor de gekozen hoofdstukken.
   Weggegooide kaarten tellen niet mee. Dezelfde telling als op de hoofdstukkenpagina. */
function telJuistFout(hoofdstukken) {
  let juist = 0, fout = 0, totaal = 0;
  for (const hfst of hoofdstukken) {
    for (const k of vakken[huidigVak][hfst] || []) {
      const id = kaartId(huidigVak, hfst, k);
      if (verborgen.has(id)) continue;
      totaal++;
      if (!stats[id]) continue;
      if (stats[id].laatst === true) juist++;
      else if (stats[id].laatst === false) fout++;
    }
  }
  return { juist, fout, totaal, nieuw: totaal - juist - fout };
}

/* Links naast de kaart: de stand van de gekozen hoofdstukken (over al je sessies) */
function toonStand(t) {
  const el = document.getElementById("stand");
  if (!el) return;
  const titel = gekozenHoofdstukken.length === 1 ? gekozenHoofdstukken[0] : `${gekozenHoofdstukken.length} hoofdstukken`;
  const pct = n => t.totaal ? (n / t.totaal * 100) : 0;
  el.innerHTML = `
    <div class="stand-titel">${maakVeilig(titel)}</div>
    <div class="stand-rij"><span>Totaal kaarten</span><b>${t.totaal}</b></div>
    <div class="stand-rij"><span>Onbeantwoord</span><b>${t.nieuw}</b></div>
    <div class="stand-rij groen"><span>Juist</span><b>${t.juist}</b></div>
    <div class="stand-rij rood"><span>Fout</span><b>${t.fout}</b></div>
    <div class="stand-balk" title="groen = juist, rood = fout, grijs = nog niet beantwoord">
      <span class="b-juist" style="width:${pct(t.juist)}%"></span><span class="b-fout" style="width:${pct(t.fout)}%"></span>
    </div>`;
}

function toonKaart() {
  const kaart = stapel[index];
  zetOngedaanKnoppen();
  bewaarSessie();
  if (hervatbaar) {
    posities[positieSleutel()] = kaartId(huidigVak, kaart.hfst, kaart);
    bewaar("posities", posities);
  }
  document.getElementById("kaart").classList.remove("omgedraaid");
  document.getElementById("antwoordKnoppen").style.display = "none";
  document.getElementById("hint").style.display = "block";
  // teller + aantal juist (groen) en fout (rood): zelfde telling als op de hoofdstukkenpagina
  const t = telJuistFout(gekozenHoofdstukken);
  document.getElementById("teller").innerHTML =
    `<span title="Waar je zit in deze ronde (enkel de kaarten die je filters toelaten)">Kaart ${index + 1} van ${stapel.length}</span>` +
    // op smallere schermen blijven ✓ en ✗ bovenaan; op brede schermen staan ze links (toonStand)
    `<span class="groen kort">Juist ${t.juist}</span>` +
    `<span class="rood kort">Fout ${t.fout}</span>`;
  toonStand(t);
  const vraagEl = document.getElementById("vraag");
  vraagEl.textContent = kaart.v;
  // meerkeuze/juist-fout (vraag over meerdere regels): links uitlijnen, leest makkelijker
  vraagEl.classList.toggle("meerkeuze", kaart.v.includes("\n"));
  vraagEl.classList.toggle("code", /\n {2,}/.test(kaart.v));
  // tekening op de voorkant (bv. met nummers i.p.v. de namen)
  zetFiguur("figVoor", kaart.img);
  document.getElementById("figAchter").innerHTML = "";

  // titel bovenaan: hoofdstuk › onderwerp
  const titel = kaart.o ? `${kaart.hfst} › ${kaart.o}` : kaart.hfst;
  document.getElementById("onderwerpVoor").textContent = titel;

  // achterkant pas invullen na de draai, zodat je het antwoord niet ziet flitsen
  setTimeout(() => {
    document.getElementById("onderwerpAchter").textContent = titel;
    const antwoordEl = document.getElementById("antwoord");
    antwoordEl.textContent = kaart.a;
    // ingesprongen regels (bv. een .yaml-bestand): in een vaste letterbreedte, spaties blijven staan
    antwoordEl.classList.toggle("code", /\n {2,}/.test(kaart.a));
    document.getElementById("uitleg").textContent = kaart.uitleg || "";
    // achterkant: de volledige tekening (met namen), anders dezelfde als voorkant
    zetFiguur("figAchter", kaart.imgAntwoord || kaart.img);
    pasHoogteAan();
  }, 250);

  // overzicht als laatste: als daar iets misloopt, werkt de kaart toch
  try { toonOverzicht(kaart); } catch (e) { console.error("Overzicht:", e); }
}

/* Overzicht rechts van de kaart: enkel het huidige hoofdstuk
   met zijn onderwerpen, en een aanduiding waar je je bevindt. */
function onderwerpenVan(hfst) {
  const lijst = [];
  for (const k of vakken[huidigVak][hfst]) {
    const o = k.o || hfst;
    if (!lijst.includes(o)) lijst.push(o);
  }
  return lijst;
}

function toonOverzicht(kaart) {
  const vak = document.getElementById("overzicht");
  if (!vak) return;
  const huidig = kaart.o || kaart.hfst;
  // volgorde van de slides als die bestaat, anders de volgorde van de kaarten
  const structuur = vakken[huidigVak][kaart.hfst].structuur ||
                    onderwerpenVan(kaart.hfst).map(o => ({ o }));

  vak.innerHTML =
    `<h3>${kaart.hfst}</h3><ol class="ov-onderwerpen">` +
    structuur.map(r => {
      // kan je naar dit onderwerp springen? enkel als er in deze ronde nog kaarten van zijn
      const spring = r.o && r.o !== huidig && eersteKaartVan(kaart.hfst, r.o) >= 0;
      const leeg = r.o && r.o !== huidig && !spring;
      const klassen = [r.sub ? "sub" : "", r.kop ? "kop" : "", r.o && r.o === huidig ? "hier" : "",
                       spring ? "klikbaar" : "", leeg ? "leeg" : ""].join(" ");
      const data = spring ? ` data-o="${encodeURIComponent(r.o)}" title="Ga naar de kaarten van dit onderwerp"` :
                   leeg ? ` title="Geen kaarten van dit onderwerp in deze ronde"` : "";
      return `<li class="${klassen}"${data}><span>${r.o || r.kop}</span>` +
             (r.slide ? `<small>${r.slide}</small>` : "") + `</li>`;
    }).join("") +
    `</ol>`;

  // huidig onderwerp in beeld houden binnen het paneel
  const hier = vak.querySelector("li.hier");
  if (hier && vak.scrollHeight > vak.clientHeight) {
    const boven = hier.offsetTop - vak.scrollTop;
    if (boven < 0 || boven > vak.clientHeight - hier.offsetHeight) vak.scrollTop = hier.offsetTop - vak.clientHeight / 3;
  }
}

/* In het overzicht op een onderwerp klikken: naar de eerste kaart van dat onderwerp
   in deze ronde springen (vooruit of terug). Kaarten die je overslaat blijven onbeantwoord. */
function eersteKaartVan(hfst, o) {
  // liefst de eerstvolgende kaart na de huidige, anders de eerste in de ronde
  const past = k => k.hfst === hfst && (k.o || k.hfst) === o;
  for (let i = index + 1; i < stapel.length; i++) if (past(stapel[i])) return i;
  return stapel.findIndex(past);
}
document.addEventListener("click", e => {
  const li = e.target.closest("#overzicht li.klikbaar");
  if (!li || bezig) return;
  const kaart = stapel[index];
  const i = eersteKaartVan(kaart.hfst, decodeURIComponent(li.dataset.o));
  if (i < 0) return;
  index = i;
  toonKaart();
});

/* Kaart laten meegroeien met een lange uitleg (in plaats van scrollen) */
/* Tekening op de kaart zetten, met een knopje om ze groot te bekijken */
function zetFiguur(id, src) {
  const vak = document.getElementById(id);
  vak.innerHTML = "";
  if (!src) return;
  const img = document.createElement("img");
  img.src = src;
  img.alt = "tekening";
  img.onload = pasHoogteAan;                        // kaart groter maken als de tekening geladen is
  img.onerror = () => { vak.innerHTML = `<div class="fig-fout">⚠️ Tekening niet gevonden: ${src}</div>`; };
  const knop = document.createElement("button");
  knop.className = "vergroot";
  knop.type = "button";
  knop.title = "Groot bekijken (G)";
  knop.innerHTML = "⤢ <span class=\"toets\">G</span>";
  knop.onclick = e => { e.stopPropagation(); toonGroot(img.src); };  // niet omdraaien
  vak.append(img, knop);
}
function toonGroot(src) {
  document.getElementById("grootImg").src = src;
  document.getElementById("grootFig").classList.add("open");
}
function sluitGroot() {
  document.getElementById("grootFig").classList.remove("open");
}
// G: de tekening van de kant die je nu ziet groot tonen
function vergrootHuidige() {
  const omgedraaid = document.getElementById("kaart").classList.contains("omgedraaid");
  const img = document.querySelector((omgedraaid ? "#figAchter" : "#figVoor") + " img");
  if (img) toonGroot(img.src);
}

function pasHoogteAan() {
  const kaartEl = document.getElementById("kaart");
  const achter = kaartEl.querySelector(".achterkant");
  const voor = kaartEl.querySelector(".voorkant");
  kaartEl.style.height = "";                       // eerst terug naar de standaardhoogte
  let nodig = Math.max(achter.scrollHeight, voor.scrollHeight) + 2;
  // niet hoger dan het scherm: dan scrolt de kaart zelf (knoppen blijven zichtbaar)
  const ruimte = window.innerHeight - kaartEl.getBoundingClientRect().top - 80;
  nodig = Math.min(nodig, Math.max(ruimte, 400));
  // vergelijken met de standaardhoogte (400px uit style.css), niet met clientHeight:
  // door de animatie op de hoogte is clientHeight op dit moment nog de oude hoogte
  kaartEl.style.height = nodig > 400 ? nodig + "px" : "";
}

function draaiOm() {
  const kaart = document.getElementById("kaart");
  kaart.classList.toggle("omgedraaid");
  if (kaart.classList.contains("omgedraaid")) {
    document.getElementById("antwoordKnoppen").style.display = "flex";
    document.getElementById("hint").style.display = "none";
  }
}

let bezig = false;   // even wachten terwijl de kaart groen/rood oplicht
let acties = [];      // wat je deze ronde deed, om ongedaan te maken (Z)
let eindeInfo = null; // wat toonEinde veranderde, om dat ook terug te draaien

function volgende(wistHet) {
  if (bezig) return;
  const kaart = stapel[index];
  if (!wistHet) fouten.push(kaart);

  // onthoud dit antwoord voor de volgende keer
  const id = kaartId(huidigVak, kaart.hfst, kaart);
  acties.push({ soort: "antwoord", index, id, vorig: stats[id] ? { ...stats[id] } : undefined, fout: !wistHet, boven: eenhoornBoven });
  const s = stats[id] || { goed: 0, fout: 0 };
  if (wistHet) s.goed++; else s.fout++;
  s.laatst = wistHet;
  stats[id] = s;
  bewaar("stats", stats);
  controleerEenhoorn();   // over de 50% juist gegaan? dan galoppeert de eenhoorn

  // rand van de kaart even groen (juist) of rood (fout) laten oplichten
  const kaartEl = document.getElementById("kaart");
  const flits = wistHet ? "flits-goed" : "flits-fout";
  kaartEl.classList.add(flits);
  bezig = true;
  setTimeout(() => {
    kaartEl.classList.remove(flits);
    bezig = false;
    index++;
    if (index < stapel.length) toonKaart();
    else toonEinde();
  }, 450);
}

/* ---------- Ongedaan maken (Z) ----------
   Zet je laatste antwoord of weggegooide kaart terug, ook vanaf het eindscherm.
   De kaart komt terug met het antwoord zichtbaar, zodat je meteen opnieuw kan kiezen. */
function maakOngedaan() {
  if (bezig || acties.length === 0) return;
  const actie = acties.pop();

  // kwam je van het eindscherm? dan ook de bewaarde score en positie terugdraaien
  if (document.getElementById("schermEinde").classList.contains("actief") && eindeInfo) {
    if (eindeInfo.scoreBewaard && scores[huidigVak]) { scores[huidigVak].pop(); bewaar("scores", scores); }
    hervatbaar = eindeInfo.hervatbaar;
    if (eindeInfo.positie) { posities[positieSleutel()] = eindeInfo.positie; bewaar("posities", posities); }
    eindeInfo = null;
  }

  if (actie.soort === "antwoord") {
    if (actie.vorig) stats[actie.id] = actie.vorig; else delete stats[actie.id];
    bewaar("stats", stats);
    if (actie.fout) fouten.pop();
  } else {
    verborgen.delete(actie.id);
    bewaarVerborgen();
    stapel.splice(actie.index, 0, actie.kaart);
  }
  eenhoornBoven = actie.boven;   // eenhoorn-stand terug zoals vóór die actie (geen eenhoorn tonen)
  index = actie.index;
  toonScherm("schermOefenen");
  toonKaart();
  setTimeout(draaiOm, 260);   // na het invullen van de achterkant
}

function zetOngedaanKnoppen() {
  document.querySelectorAll(".ongedaan").forEach(k => k.disabled = acties.length === 0);
}

function gooiWeg() {
  if (bezig) return;
  const kaart = stapel[index];
  acties.push({ soort: "weg", index, kaart, id: kaartId(huidigVak, kaart.hfst, kaart), boven: eenhoornBoven });
  verborgen.add(kaartId(huidigVak, kaart.hfst, kaart));
  bewaarVerborgen();
  zetEenhoornStand();
  stapel.splice(index, 1);
  if (index < stapel.length) toonKaart();
  else toonEinde();
}

function toonEinde() {
  eindeInfo = { hervatbaar, positie: posities[positieSleutel()], scoreBewaard: false };
  // hoofdstuk helemaal doorlopen: volgende keer begin je terug vooraan
  if (hervatbaar) { delete posities[positieSleutel()]; bewaar("posities", posities); hervatbaar = false; }
  const score = document.getElementById("score");
  if (stapel.length === 0) {
    score.textContent = "Geen kaarten meer";
  } else {
    const goed = stapel.length - fouten.length;
    score.textContent = `${goed} / ${stapel.length}`;

    // score bewaren in de geschiedenis van dit vak (max. 20)
    const lijst = scores[huidigVak] || [];
    const nu = new Date();
    lijst.push({
      datum: nu.toLocaleDateString("nl-BE") + " " + nu.toLocaleTimeString("nl-BE", { hour: "2-digit", minute: "2-digit" }),
      goed: goed,
      totaal: stapel.length,
    });
    scores[huidigVak] = lijst.slice(-20);
    bewaar("scores", scores);
    eindeInfo.scoreBewaard = true;
  }
  document.getElementById("herhaalKnop").style.display = fouten.length ? "block" : "none";
  // knop met de naam van het vak, bv. "Terug naar de hoofdstukken van IT Essentials"
  const vakNaam = huidigVak.replace(/^\S+\s/, "");   // emoji vooraan weglaten
  document.getElementById("terugHoofdstukken").textContent = `Terug naar de hoofdstukken van ${vakNaam}`;
  toonScherm("schermEinde");
  zetOngedaanKnoppen();
}

function herhaalFouten() {
  startOefenen(fouten);
}

/* ===== Beloning: eenhoorn =====
   Kijkt naar de totaalstand links (juist / (juist + fout), over al je sessies).
   Ga je over de 50%, dan galoppeert er een eenhoorn over het scherm.
   Daarna niet meer, tot je eerst weer onder de 50% zakt. Precies 50% verandert niets. */
let eenhoornBoven = false;

function procentJuist() {
  const t = telJuistFout(gekozenHoofdstukken);
  const beantwoord = t.juist + t.fout;
  return beantwoord ? t.juist / beantwoord : null;
}

// stand bepalen zonder eenhoorn te tonen (bij start, refresh, ongedaan maken, weggooien)
function zetEenhoornStand() {
  const p = procentJuist();
  if (p === null || p < 0.5) eenhoornBoven = false;
  else if (p > 0.5) eenhoornBoven = true;
}

// na een antwoord: over de grens gegaan? dan eenhoorn tonen
function controleerEenhoorn() {
  const p = procentJuist();
  if (p === null) return;
  if (p > 0.5 && !eenhoornBoven) { eenhoornBoven = true; toonEenhoorn(); }
  else if (p < 0.5) eenhoornBoven = false;
}

const EENHOORN_SVG = `
<svg viewBox="-30 -30 180 160" aria-hidden="true">
<path class="eh-tw" d="M-22 60 l3 7 7 3 -7 3 -3 7 -3 -7 -7 -3 7 -3z" fill="#DCDCAA"/>
<path class="eh-tw" d="M-8 88 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" fill="#9FE1CB"/>
<g transform="translate(70,90)"><g class="eh-rock eh-p"><g transform="translate(-70,-90)">
<g transform="translate(42,58)"><g class="eh-hair eh-p"><g transform="translate(-42,-58)">
<path d="M44 56 Q22 44 12 62 Q2 82 12 106 Q12 92 20 88 Q16 104 28 112 Q26 96 34 88 Q30 100 40 104 Q36 86 42 76 Q46 66 48 62Z" fill="#3B6D11"/>
<path d="M40 60 Q22 58 18 76 Q16 88 22 96 Q22 82 30 76 Q28 88 34 94 Q34 78 42 68Z" fill="#6A9955"/>
<path d="M30 64 Q22 74 24 88" stroke="#97C459" stroke-width="1.4" fill="none" stroke-linecap="round"/>
</g></g></g>
<g transform="translate(45,70)"><g class="eh-hu2 eh-p"><path d="M-8 -8 L6 -8 L3.5 22 L-3 22Z" fill="#2E8B6E"/><g transform="translate(0,21)"><g class="eh-hk2 eh-p"><rect x="-2.5" y="-1" width="5" height="18" rx="2.5" fill="#2E8B6E"/><path d="M-4 13 L4 13 L5 16 L-5 16Z" fill="#5DCAA5"/><path d="M-4 15 L4 15 L6 22 L-6 22Z" fill="#173404"/></g></g></g></g>
<g transform="translate(88,70)"><g class="eh-fu2 eh-p"><path d="M-5 -6 L5 -6 L3 22 L-3 22Z" fill="#2E8B6E"/><g transform="translate(0,21)"><g class="eh-fk2 eh-p"><rect x="-2.5" y="-1" width="5" height="18" rx="2.5" fill="#2E8B6E"/><path d="M-4 13 L4 13 L5 16 L-5 16Z" fill="#5DCAA5"/><path d="M-4 15 L4 15 L6 22 L-6 22Z" fill="#173404"/></g></g></g></g>
<circle cx="50" cy="62" r="17" fill="#3FB68E"/>
<ellipse cx="70" cy="66" rx="28" ry="15" fill="#3FB68E"/>
<circle cx="90" cy="64" r="15" fill="#3FB68E"/>
<path d="M58 78 Q70 82 84 78" stroke="#2E8B6E" stroke-width="1.2" fill="none" stroke-linecap="round"/>
<g transform="translate(52,72)"><g class="eh-hu1 eh-p"><path d="M-9 -8 L7 -8 L4 22 L-3 22Z" fill="#3FB68E"/><g transform="translate(0,21)"><g class="eh-hk1 eh-p"><rect x="-2.5" y="-1" width="5" height="18" rx="2.5" fill="#3FB68E"/><path d="M-4 13 L4 13 L5 16 L-5 16Z" fill="#9FE1CB"/><path d="M-4 15 L4 15 L6 22 L-6 22Z" fill="#27500A"/></g></g></g></g>
<g transform="translate(94,72)"><g class="eh-fu1 eh-p"><path d="M-6 -6 L6 -6 L3.5 22 L-3.5 22Z" fill="#3FB68E"/><g transform="translate(0,21)"><g class="eh-fk1 eh-p"><rect x="-2.5" y="-1" width="5" height="18" rx="2.5" fill="#3FB68E"/><path d="M-4 13 L4 13 L5 16 L-5 16Z" fill="#9FE1CB"/><path d="M-4 15 L4 15 L6 22 L-6 22Z" fill="#27500A"/></g></g></g></g>
<text x="40" y="66" font-size="11" font-family="monospace" fill="#085041">&lt;/&gt;</text>
<g transform="translate(92,58)"><g class="eh-nod eh-p"><g transform="translate(-92,-58)">
<path d="M82 60 Q84 36 104 20 L126 30 Q108 44 104 70Z" fill="#3FB68E"/>
<path d="M110 0 Q92 -6 86 12 Q76 20 80 36 Q72 46 78 60 Q82 52 88 54 Q84 42 94 38 Q90 28 100 26 Q98 16 110 14Z" fill="#3B6D11"/>
<path d="M104 6 Q92 8 90 22 Q86 32 88 44 Q92 34 98 30 Q94 22 102 16Z" fill="#6A9955"/>
<path d="M96 12 Q88 22 90 34 M86 40 Q82 48 84 56" stroke="#97C459" stroke-width="1.3" fill="none" stroke-linecap="round"/>
<circle cx="118" cy="22" r="17" fill="#3FB68E"/>
<ellipse cx="134" cy="32" rx="12" ry="10" fill="#52C49A"/>
<ellipse cx="139" cy="29" rx="1.6" ry="2.2" fill="#085041"/>
<path d="M129 39 q5 4 10 0" stroke="#085041" stroke-width="1.5" fill="none" stroke-linecap="round"/>
<path d="M106 8 Q100 -12 113 -7 Q116 1 114 9Z" fill="#3FB68E"/>
<path d="M108 4 Q105 -6 111 -4 Q112 1 111 6Z" fill="#9FE1CB"/>
<path d="M120 6 L131 -20 L126 8Z" fill="#DCDCAA"/>
<path d="M124 -4 l5 1.5 M122 2 l5 1.5 M127 -11 l3 1" stroke="#BA7517" stroke-width="1.2"/>
<path d="M110 2 Q122 -8 132 4 Q126 2 124 10 Q120 3 114 12 Q112 6 108 8Z" fill="#3B6D11"/>
<path d="M116 2 Q123 -2 128 4 Q122 3 120 7Z" fill="#6A9955"/>
<ellipse cx="122" cy="22" rx="7" ry="8.5" fill="#fff"/>
<ellipse cx="123.5" cy="23" rx="5.5" ry="7" fill="#0F6E56"/>
<circle cx="124" cy="24" r="3.4" fill="#04342C"/>
<circle cx="125.8" cy="20.5" r="2" fill="#fff"/>
<circle cx="122" cy="27" r="1" fill="#fff"/>
<path d="M115.5 16 Q122 11 129 15.5 M128 15 l3.5 -3 M126 13.5 l2 -4 M123 13 l0.5 -4" stroke="#04342C" stroke-width="1.6" fill="none" stroke-linecap="round"/>
<ellipse cx="125" cy="33" rx="4" ry="2.2" fill="#F4C0D1"/>
</g></g></g>
</g></g></g>
</svg>`;

function toonEenhoorn() {
  const oud = document.getElementById("eenhoorn");
  if (oud) oud.remove();                 // nooit twee tegelijk
  const laag = document.createElement("div");
  laag.id = "eenhoorn";
  laag.innerHTML = `<div class="eh-loper">${EENHOORN_SVG}</div>`;
  document.body.appendChild(laag);
  const loper = laag.querySelector(".eh-loper");
  loper.addEventListener("animationend", e => { if (e.target === loper) laag.remove(); });
  setTimeout(() => laag.remove(), 9000); // vangnet als animationend niet komt
}

/* Sneltoetsen op het oefenscherm:
   spatie = kaart omdraaien, ← = wist ik niet (rood), → = wist ik (groen), w = weggooien */
document.addEventListener("keydown", e => {
  if (e.repeat) return;
  // vergrote tekening open? Esc, spatie of G sluit ze
  const groot = document.getElementById("grootFig");
  if (groot && groot.classList.contains("open")) {
    if (["Escape", "Space", "KeyG"].includes(e.code)) { e.preventDefault(); sluitGroot(); }
    return;
  }
  // Z (of Ctrl+Z): laatste actie ongedaan maken, ook op het eindscherm
  if ((e.key === "z" || e.key === "Z") &&
      (document.getElementById("schermOefenen").classList.contains("actief") ||
       document.getElementById("schermEinde").classList.contains("actief"))) {
    e.preventDefault();
    maakOngedaan();
    return;
  }
  if (!document.getElementById("schermOefenen").classList.contains("actief")) return;
  if (e.key === "g" || e.key === "G") { e.preventDefault(); vergrootHuidige(); return; }
  // pijltjes werken zodra je het antwoord gezien hebt (ook als je de kaart terug omdraaide)
  const knoppenZichtbaar = document.getElementById("antwoordKnoppen").style.display === "flex";

  if (e.code === "Space") {
    e.preventDefault();                                       // niet laten scrollen
    if (document.activeElement) document.activeElement.blur(); // geen knop per ongeluk indrukken
    draaiOm();
  } else if (e.key === "ArrowLeft" && knoppenZichtbaar) {    // pas na het omdraaien
    e.preventDefault();
    volgende(false);
  } else if (e.key === "ArrowRight" && knoppenZichtbaar) {
    e.preventDefault();
    volgende(true);
  } else if (e.key === "w" || e.key === "W") {              // w = kaart weggooien
    e.preventDefault();
    gooiWeg();
  }
});

toonVakken();
herstelSessie();

/* verder-info bijwerken als je hoofdstukken of schudden aan/uit vinkt;
   je keuze voor schudden wordt ook onthouden */
document.getElementById("hoofdstukLijst").addEventListener("change", () => { toonVerderInfo(); bewaarSessie(); });
document.getElementById("alles").addEventListener("change", () => setTimeout(() => { toonVerderInfo(); bewaarSessie(); }));
(() => {
  const schudden = document.getElementById("schudden");
  schudden.checked = laad("schudden", "nee") === "ja";
  schudden.addEventListener("change", () => { bewaar("schudden", schudden.checked ? "ja" : "nee"); toonVerderInfo(); });
})();

// scherm groter/kleiner gemaakt: kaarthoogte opnieuw berekenen
window.addEventListener("resize", () => {
  if (document.getElementById("schermOefenen").classList.contains("actief")) pasHoogteAan();
});
